def summarize(intent,df,region=None):
 s=f' in {region}' if region else ''
 if intent=='overdue_invoices': return f'Found {len(df)} overdue invoices{s}; outstanding INR {df.outstanding_amount.sum():,.2f}.'
 if intent=='delayed_orders': return f'Found {len(df)} delayed orders{s}; value INR {df.order_amount.sum():,.2f}.'
 if intent=='overdue_and_pending': return f'Found {len(df)} matching customer records{s}.'
 return f'Results summarized across {len(df)} regions.'
