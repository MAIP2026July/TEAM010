# VirtualData AI
**Enterprise Chatbot on Top of a Data Virtualization Layer**

Functional MVP for **MBA ZG583: Management of AI Products**.

## Team
**VirtualData AI**
- Tapan Kumar Mohapatra
- R Subith

## MVP flow
Business question -> controlled intent -> role validation -> approved virtual view -> read-only query -> explainable response.

## Capabilities
Synthetic customers, invoices, orders and payments; governed SQLite views; role controls; ambiguity handling; source/query transparency; automated tests.

## Run
```bash
python -m venv .venv
pip install -r requirements.txt
streamlit run app.py
```
See [MVP_README.md](MVP_README.md). All records are synthetic. SQLite simulates the data-virtualization layer; no enterprise credentials or confidential data are used.
