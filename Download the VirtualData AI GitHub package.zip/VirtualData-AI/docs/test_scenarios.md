# Demo scenarios
1. Show overdue invoices for Western region.
2. Total outstanding amount by region.
3. Customers with overdue invoices and pending orders.
4. Delayed orders for Western region.
5. Revenue last month (clarification).
6. Credit limits (blocked).
