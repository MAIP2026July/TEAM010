import pandas as pd, streamlit as st
from virtualdata.database import create_database
from virtualdata.intent import parse_question
from virtualdata.governance import authorize
from virtualdata.query_builder import build_query
from virtualdata.response import summarize
st.set_page_config(page_title='VirtualData AI',layout='wide');st.title('VirtualData AI');st.caption('Governed conversational analytics using synthetic data')
role=st.selectbox('Demo role',['Finance Analyst','Sales Analyst','Operations Analyst']); q=st.text_input('Ask a business question','Show overdue invoices for the Western region.')
if st.button('Ask VirtualData AI',type='primary'):
 x=parse_question(q)
 if x['intent']=='ambiguous_revenue': st.warning('Revenue is ambiguous. Specify invoiced or recognized revenue.');st.stop()
 if x['intent']=='unsupported': st.error('Outside validated MVP patterns.');st.stop()
 ok,v,msg=authorize(role,x['intent'])
 if not ok: st.error('Access Restricted');st.write(msg);st.stop()
 sql,p=build_query(x); df=pd.read_sql_query(sql,create_database(),params=p);st.success(summarize(x['intent'],df,x.get('region')));st.dataframe(df,use_container_width=True,hide_index=True)
 with st.expander('How this answer was generated',expanded=True): st.write('Intent:',x['intent']);st.write('Approved view:',v);st.write('Authorization:',msg);st.code(sql,'sql');st.write('Parameters:',p)
