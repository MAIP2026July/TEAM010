import pandas as pd
from virtualdata.intent import parse_question
from virtualdata.governance import authorize
from virtualdata.query_builder import build_query
from virtualdata.database import create_database
def test_intent(): assert parse_question('overdue invoices Western')['region']=='Western'
def test_governance(): assert not authorize('Operations Analyst','overdue_invoices')[0]
def test_query():
 q,p=build_query({'intent':'overdue_invoices','region':'Western'});d=pd.read_sql_query(q,create_database(),params=p);assert len(d)==5 and d.outstanding_amount.sum()==1215000
