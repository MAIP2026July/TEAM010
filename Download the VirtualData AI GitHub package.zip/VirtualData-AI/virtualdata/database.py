from pathlib import Path
import sqlite3, pandas as pd
ROOT=Path(__file__).resolve().parents[1]
def create_database():
 c=sqlite3.connect(':memory:')
 for n in ('customers','invoices','orders','payments'): pd.read_csv(ROOT/'data'/f'{n}.csv').to_sql(n,c,index=False,if_exists='replace')
 c.executescript("""CREATE VIEW vw_customer_receivables AS SELECT x.customer_name,x.region,i.invoice_id,i.due_date,i.invoice_amount-i.paid_amount outstanding_amount,i.status FROM invoices i JOIN customers x USING(customer_id); CREATE VIEW vw_order_status AS SELECT x.customer_name,x.region,o.order_id,o.expected_ship_date,o.actual_ship_date,o.order_amount,o.status FROM orders o JOIN customers x USING(customer_id); CREATE VIEW vw_customer_activity AS SELECT x.customer_name,x.region,i.invoice_id,i.invoice_amount-i.paid_amount outstanding_amount,o.order_id FROM customers x JOIN invoices i USING(customer_id) JOIN orders o USING(customer_id) WHERE i.status='OVERDUE' AND o.status='PENDING';""")
 return c
