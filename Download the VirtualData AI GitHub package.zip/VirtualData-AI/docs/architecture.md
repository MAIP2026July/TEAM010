# Architecture
User -> Streamlit -> Intent parser -> Governance check -> Approved SQLite virtual view -> Explainable result.
