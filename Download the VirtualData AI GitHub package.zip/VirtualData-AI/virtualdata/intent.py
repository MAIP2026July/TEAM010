def parse_question(q):
 q=q.lower(); region=next((x.title() for x in ('western','northern','southern','eastern') if x in q),None)
 if 'credit limit' in q:return {'intent':'credit_limit','region':region}
 if 'revenue' in q:return {'intent':'ambiguous_revenue','region':region}
 if 'overdue' in q and 'pending order' in q:return {'intent':'overdue_and_pending','region':region}
 if 'outstanding' in q and 'region' in q:return {'intent':'outstanding_by_region','region':region}
 if 'overdue' in q and 'invoice' in q:return {'intent':'overdue_invoices','region':region}
 if 'delayed' in q and 'order' in q:return {'intent':'delayed_orders','region':region}
 return {'intent':'unsupported','region':region}
