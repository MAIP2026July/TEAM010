V={'Finance Analyst':{'vw_customer_receivables','vw_order_status','vw_customer_activity'},'Sales Analyst':{'vw_customer_receivables','vw_order_status','vw_customer_activity'},'Operations Analyst':{'vw_order_status','vw_customer_activity'}}
M={'overdue_invoices':'vw_customer_receivables','outstanding_by_region':'vw_customer_receivables','delayed_orders':'vw_order_status','overdue_and_pending':'vw_customer_activity','credit_limit':'customer_credit_limit'}
def authorize(role,intent):
 v=M.get(intent); ok=v in V.get(role,set()); return ok,v,'Authorized' if ok else f'Role {role} is not permitted to access {v}.'
