# Responsible AI
Synthetic data, read-only templates, role checks, visible source/query, clarification for ambiguity, and safe rejection are built into the MVP.
