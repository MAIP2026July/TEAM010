# Run the MVP
Requires Python 3.10+.
```bash
python -m venv .venv
# activate it
pip install -r requirements.txt
streamlit run app.py
```
Run validation with `pytest -q`. All data is synthetic.
