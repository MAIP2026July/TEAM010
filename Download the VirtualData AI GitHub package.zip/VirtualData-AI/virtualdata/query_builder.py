def build_query(x):
 i=x['intent']; r=x.get('region'); p=[]
 if i=='overdue_invoices': q="SELECT * FROM vw_customer_receivables WHERE status='OVERDUE'"
 elif i=='outstanding_by_region': return "SELECT region,SUM(outstanding_amount) total_outstanding FROM vw_customer_receivables WHERE status!='PAID' GROUP BY region ORDER BY total_outstanding DESC",[]
 elif i=='delayed_orders': q="SELECT * FROM vw_order_status WHERE status='DELAYED'"
 elif i=='overdue_and_pending': q='SELECT * FROM vw_customer_activity'
 else: raise ValueError('No approved query')
 if r: q+=(' WHERE' if i=='overdue_and_pending' else ' AND')+' region=?';p=[r]
 return q,p
